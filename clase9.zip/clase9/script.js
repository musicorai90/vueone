var eventBus = new Vue()

Vue.component('producto', {
	props: {
		premium: {
			type: Boolean,
			required: true
		},
		carts: {
			type: Array,
			required: true
		}
	},
	template: `
		<div>
			<div class="product">
				<div class="colors">
					<div v-for="(variant, index) in variants" 
					 :key="variant.variantId" 
					 class="color-box"
					 :style="{ backgroundColor: variant.variantColor }" 
					 @mouseover="updateProduct(index)">
				</div>
				</div>

				<div class="product-image">
					<img :src="image">
				</div>

				<div class="product-info">
					<!-- <h1>{{ brand }} {{ product }}</h1> -->
					<h1>{{ title }}</h1>
					<p v-if="inStock > 10" style="color: green" class="stock">In Stock</p>
					<p v-else-if="inStock <= 10 && inStock > 0" style="color: orange" class="stock">Almost sold out!</p>
					<p v-else :class="{ outOfStock: !inStock }">Out of Stock</p>
					<span class="sale">{{ sale }}</span>
					<product-details :shipping="shipping" :details="details" :sizes="sizes"></product-details>
					<div class="buttons">
						<button @click="addToCart" :disabled="!inStock" :class="{ disabledButton: !inStock }">Add to cart</button> <!-- CON METODOS Y CON ARROBA -->
						<button @click="removeFromCart" :disabled="!inCart" :class="{ disabledButton: !inCart }">Remove from cart</button>
					</div>
					<div><a :href="link" target="_blank">More products like this</a></div>
				</div>
			</div>
			<products-tabs :reviews="reviews"></products-tabs>
		</div>
	`,
	data() {
		return {
			brand: "Vue Mastery",
			product: 'Socks',
			// image: 'https://www.vuemastery.com/images/challenges/vmSocks-green-onWhite.jpg',
			selectedVariant: 0,
			link: 'https://www.amazon.com/s/ref=nb_sb_noss?url=search-alias%3Daps&field-keywords=socks',
			onSale: true,
			details: ["80% cotton","20% polyester","Gender-neutral"],
			variants: [
				{
					variantId: 2234,
					variantColor: "green",
					variantImage: 'https://www.vuemastery.com/images/challenges/vmSocks-green-onWhite.jpg',
					variantQuantity: 10
				},
				{
					variantId: 2235,
					variantColor: "blue",
					variantImage: 'https://www.vuemastery.com/images/challenges/vmSocks-blue-onWhite.jpg',
					variantQuantity: 0
				}
			],
			sizes: ['S', 'M', 'L', 'XL', 'XXL', 'XXXL'],
			onSale: true,
			reviews: [],
		}
	},
	methods: {
		/*addToCart: function() {
			this.cart += 1
		},
		updateProduct: function(variantImage) {
			this.image = variantImage
		}*/
		addToCart() {
			this.$emit('add-to-cart',this.variants[this.selectedVariant].variantId)
		},
		updateProduct(index) {
			this.selectedVariant = index
		},
		removeFromCart() {
			this.$emit('remove-from-cart', this.variants[this.selectedVariant].variantId)
		}
	},
	computed: {
		title() {
			return this.brand + ' ' + this.product
		},
		image() {
			return this.variants[this.selectedVariant].variantImage
		},
		inStock() {
			return this.variants[this.selectedVariant].variantQuantity
		},
		sale() {
			if (this.onSale) {
				return this.brand + ' ' + this.product + ' are on Sale!'
			} return this.brand + ' ' + this.product + " aren't on Sale!"
		},
		shipping() {
			if (this.premium) {
				return "Free"
			} return 2.99
		},
		inCart() {
			if (this.carts.indexOf(this.variants[this.selectedVariant].variantId) != -1) {
			  return true
			} return false
		}
	},
	mounted() {
		eventBus.$on('review-submitted', productReview => {
			this.reviews.push(productReview)
		})
	}
})

Vue.component('product-review', {
	template: `
		<form class="review-form" @submit.prevent="onSubmit">
			<p v-if="errors.length">
				<b>Please correct the following error(s):</b>
				<ul>
					<li v-for="error in errors">{{ error }}</li>
				</ul>
			</p>
			<p>
				<label for="name">Name:</label>
				<input class="form-control" id="name" v-model="name" placeholder="Name">
			</p>

			<p>
				<label for="review">Review:</label>      
				<textarea class="form-control" id="review" v-model="review" placeholder="Review"></textarea>
			</p>

			<p>
				<label for="rating">Rating:</label>
				<select class="form-control" id="rating" v-model.number="rating">
					<option>5</option>
					<option>4</option>
					<option>3</option>
					<option>2</option>
					<option>1</option>
				</select>
			</p>
			<p>
				<span>Would you recommend this product?</span>
				<div class="form-options">
					<div class="form-option">
						<label>Yes</label>
						<input type="radio" v-model="recommend" value="Yes">
					</div>
					<div class="form-option">
						<label>No</label>
						<input type="radio" v-model="recommend" value="No">
					</div>
				</div>
			</p>

			<p class="form-btn">
				<input type="submit" value="Submit">  
			</p>    

		</form>
	`,
	data() {
		return {
			name: null,
			review: null,
			rating: null,
			recommend: null,
			errors: []
		}
	},
	methods: {
		onSubmit() {
			this.errors = []
			if (this.name && this.review && this.rating && this.recommend) {
				let productReview = {
					name: this.name,
					review: this.review,
					rating: Number(this.rating),
					recommend: this.recommend
				}
				eventBus.$emit('review-submitted',productReview)
				this.name = null
				this.review = null
				this.rating = null
				this.recommend = null
			} else {
				if (!this.name) this.errors.push("Name required.")
				if (!this.review) this.errors.push("Review required.")
				if (!this.rating) this.errors.push("Rating required.")
				if (!this.recommend) this.errors.push("Rating recommend.")
			}
		}
	}
})

Vue.component('products-tabs', {
	props: {
		reviews: {
			type: Array,
			required: true
		}
	},
	template: `
		<div class="reviews">
			<div>
				<span :class="{ activeTab: selectedTab === tab }" class="tab" v-for="(tab, index) in tabs" :key="index" @click="selectedTab = tab">{{ tab }}</span>
			</div>

			<div class="reviews-box">
				<div v-show="selectedTab === 'Reviews'">
					<p v-if="!reviews.length">There are no reviews yet.</p>
					<ul>
						<li v-for="review in reviews" class="review">
							<p class="review-name"><b>{{ review.name }}</b> - Rating: {{ review.rating }}</p>
							<p class="review-review">{{ review.review }}</p>
							<p class="review-recommend"><b>Recommend this product:</b> <span :class="{ green: review.recommend === 'Yes', red: review.recommend === 'No' }">{{ review.recommend }}</p>
						</li>
					</ul>
				</div>
				<product-review v-show="selectedTab === 'Make a Review'"></product-review>
			</div>
		</div>
	`,
	data() {
		return {
			tabs: ['Reviews','Make a Review'],
			selectedTab: 'Reviews'
		} 
	}
})

Vue.component('product-details', {
  props: {
    shipping: {
      required: true
    },
    details: {
      type: Array,
      required: true
    },
    sizes: {
    	type: Array,
    	required: true
    }
  },
  template: `
    <div>
      <div class="tabs">
      	<span class="tab" :class="{ activeTab: selectedTab === tab }" v-for="(tab, index) in tabs" :key="index" @click="selectedTab = tab">{{ tab }}</span>
      </div>
      <div class="details">
	      <p v-show="selectedTab === 'Shipping'"><b>Shipping:</b> {{ shipping }}</p>
	      <ul v-show="selectedTab === 'Details'">
	        <li v-for="detail in details">{{ detail }}</li>
	      </ul>
	      <ul v-show="selectedTab === 'Sizes'">
			<li v-for="size in sizes">{{ size }}</li>
	      </ul>
	    </div>
    </div>
  `,
  data() {
    return {
      tabs: ['Shipping', 'Details','Sizes'],
      selectedTab: 'Shipping'
    }
  }
})


var app = new Vue({
	el: '#app',
	data: {
		premium: true, //false
		cart: []
	},
	methods: {
		updateCart(id) {
			this.cart.push(id)
		},
		removeItem(id) {
          if (this.cart.indexOf(id) != -1) {
            this.cart.splice(this.cart.indexOf(id),1)
          }
        }
	}
})